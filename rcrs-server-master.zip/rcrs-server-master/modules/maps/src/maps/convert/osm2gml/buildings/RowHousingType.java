package maps.convert.osm2gml.buildings;

//CHECKSTYLE:OFF:JavadocType|JavadocVariable
public enum RowHousingType {
    T_SHAPE_ROW,
    T_SHAPE_DUPLEX,
    RECTANGULAR_DUPLEX, // Done
    THIN_DUPLEX,
    SQUARE_DETACHED,
    L_SHAPE_DETACHED,
//CHECKSTYLE:ON:JavadocType|JavadocVariable
}
