package maps.gml.editor;

/**
   Exception for indicating the the user has cancelled an operation.
*/
public class CancelledByUserException extends Exception {
    /**
       Constructor.
    */
    public CancelledByUserException() {}
}